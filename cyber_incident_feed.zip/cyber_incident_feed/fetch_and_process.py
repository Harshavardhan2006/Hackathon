import snscrape.modules.twitter as sntwitter
import joblib
import json
from datetime import datetime

model = joblib.load("classifier.pkl")

def is_relevant(text):
    return model.predict([text])[0] == 1

def extract_entities(text):
    sector = "Energy" if "power" in text.lower() else "Unknown"
    return {
        "title": text[:100],
        "description": text,
        "sector": sector,
        "timestamp": datetime.now().isoformat()
    }

def fetch_tweets(keyword="cyberattack India", max_results=20):
    tweets = []
    import ssl
    import urllib3
    ssl._create_default_https_context = ssl._create_unverified_context
    urllib3.disable_warnings()

for i, tweet in enumerate(sntwitter.TwitterSearchScraper(keyword).get_items()):
        if i >= max_results:
            break
        if is_relevant(tweet.content):
            structured = extract_entities(tweet.content)
            tweets.append(structured)
    return tweets

def save_to_file(data, filename="data.json"):
    with open(filename, "w") as f:
        json.dump(data, f, indent=2)

if __name__ == "__main__":
    all_data = fetch_tweets()
    save_to_file(all_data)
    print(f"{len(all_data)} cyber incidents saved to data.json")