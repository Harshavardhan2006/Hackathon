# Offline Cyber Incident Feed Tool

This project collects and displays cyber incidents related to Indian cyberspace using open-source tools.

## How to Use

1. Install dependencies:
    pip install -r requirements.txt

2. Run the data collection:
    python fetch_and_process.py

3. Launch the dashboard:
    streamlit run streamlit_dashboard.py

## Dependencies
- snscrape
- scikit-learn
- joblib
- streamlit
- pandas