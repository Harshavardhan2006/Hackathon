import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

data = {
    'timestamp': ["2025-04-04 10:30:00", "2025-04-03 14:20:00", "2025-04-02 08:15:00"],
    'title': ["Bank Data Breach", "Defense System Hack", "Transport Network Attack"],
    'sector': ["Finance", "Defence", "Transport"],
    'severity': ["High", "Critical", "Medium"],
    'source': ["CERT-In", "News", "Twitter"]
}
df = pd.DataFrame(data)
df['timestamp'] = pd.to_datetime(df['timestamp'])

def severity_label(sev):
    if sev == "Critical":
        return "🔴 Critical"
    elif sev == "High":
        return "🟠 High"
    elif sev == "Medium":
        return "🟡 Medium"
    else:
        return "🟢 Low"

df['Severity Level'] = df['severity'].apply(severity_label)

st.set_page_config(page_title="Indian Cyber Incident Dashboard", layout="wide")
st.title("\U0001F6E1 Indian Cyber Incident Dashboard")

col1, col2, col3 = st.columns(3)
col1.metric("Total Incidents", len(df))
col2.metric("Most Affected Sector", df['sector'].mode()[0])
col3.metric("Latest Incident", df.iloc[0]['title'])

st.subheader("📊 Incidents by Sector")
fig = px.bar(df['sector'].value_counts(), 
             labels={'index': 'Sector', 'value': 'Incidents'},
             title="Incidents by Sector",
             color=df['sector'].value_counts().index)
st.plotly_chart(fig, use_container_width=True)

st.subheader("📈 Incidents Over Time")
time_series = df.groupby(df['timestamp'].dt.date).size().reset_index(name='Incidents')
time_series.rename(columns={time_series.columns[0]: 'Date'}, inplace=True)
fig_line = px.line(time_series, x='Date', y='Incidents', title='Trend of Cyber Incidents Over Time')
st.plotly_chart(fig_line, use_container_width=True)

st.subheader("⚠️ Incident Severity Distribution")
pie_fig = px.pie(df, names='severity', title="Incident Severity Levels", hole=0.4)
st.plotly_chart(pie_fig, use_container_width=True)

st.subheader("📡 Sources of Cyber Incidents")
source_chart = px.pie(df, names='source', title="Incident Sources")
st.plotly_chart(source_chart, use_container_width=True)

st.subheader("📰 Latest Cyber Incidents")
st.dataframe(df[['timestamp', 'title', 'sector', 'Severity Level', 'source']].sort_values(by="timestamp", ascending=False))

st.sidebar.header("🔍 Filter Incidents")
selected_sector = st.sidebar.multiselect("Select Sector", options=df['sector'].unique(), default=df['sector'].unique())
selected_severity = st.sidebar.multiselect("Select Severity", options=df['severity'].unique(), default=df['severity'].unique())
filtered_df = df[(df['sector'].isin(selected_sector)) & (df['severity'].isin(selected_severity))]
st.subheader("Filtered Incidents")
st.dataframe(filtered_df)

st.subheader("📰 Cybersecurity News")
news = [
    "CERT-In issues new security guidelines for enterprises.",
    "Massive ransomware attack affects 50,000 Indian businesses.",
    "AI-driven cybersecurity solutions gain momentum."
]
for item in news:
    st.write(f"- {item}")